import numpy as np
from astropy.io import ascii

prf = open('/n08data/PRFstacks/COSMOS_ch1_200130/prfmap_models_ch1.txt','r')
lines = prf.readlines()
print(len(lines))
done = np.loadtxt('done.lst')
done = [int(i) for i in done]
out = open('/n08data/PRFstacks/COSMOS_ch1_200130/prfmap_models_ch1_miss.txt','w')
out.write(lines[0])
done = []
for l in lines[1:]:
    if int(l.split()[0]) in done: 
        continue
    else: 
        out.write(l)
        done.append(int(l.split()[0]))

prf.close()
out.close()
