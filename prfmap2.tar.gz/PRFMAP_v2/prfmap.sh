#!/bin/bash

cd /n07data/PRFMAP_v2/
for i in `seq 60001 4000 220000`; do
    sed -i '/FILE_PRFS/c\FILE_PRFS\ \/n08data\/PRFstacks\/COSMOS_ch2_200310\/prfmap_models_ch2_sorted_r2_'$i'.txt' cosmos.par
    qsub prfmap1.qsub
    sleep 30
done
